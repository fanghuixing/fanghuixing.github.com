#!/bin/bash
#
phaver -v256011 subway2.pha