#!/bin/bash
#
phaver -v256011 subway.pha